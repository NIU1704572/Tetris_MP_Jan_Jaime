#ifndef _NFONT_GPU_H__
#define _NFONT_GPU_H__

#ifndef NFONT_USE_SDL_GPU
    #define NFONT_USE_SDL_GPU
#endif

#include "NFont.h"

#endif
